(function($){
  $(function(){

    $(document).ready(function(){
      $('.carousel').carousel({
        dist: 0
      });
      $('.materialboxed').materialbox();
    });

  }); // end of document ready
})(jQuery); // end of jQuery name space