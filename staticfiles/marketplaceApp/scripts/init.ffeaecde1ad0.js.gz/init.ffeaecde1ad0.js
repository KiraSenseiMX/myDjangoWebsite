(function($){
  $(function(){

    $(document).ready(function(){
      $('.carousel').carousel();
      $('.materialboxed').materialbox();
    });

  }); // end of document ready
})(jQuery); // end of jQuery name space