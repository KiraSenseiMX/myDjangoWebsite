(function($){
  $(function(){

    $('.sidenav').sidenav();

    $(document).ready(function(){
      $('select').formSelect();
    });

  }); // end of document ready
})(jQuery); // end of jQuery name space
